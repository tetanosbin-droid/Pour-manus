# MegaJarvis ai — Pont CodeAssist (Jarvis Bridge HTTP)

Patch pour la base **Kai / MegaJarvis ai** (namespace `com.inspiredandroid.kai`).

Complète le partage `ACTION_SEND` déjà décrit dans `MegaJarvis_ai.md` par un **vrai pont technique** vers le plugin Jarvis Bridge dans CodeAssist.

## Prérequis

1. **CodeAssist** installé (tyron12233/CodeAssist)
2. Plugin **Jarvis Bridge** (version FS avec `/health`, `/files`, `/file`, `/build`) installé dans CodeAssist
3. Projet ouvert dans CodeAssist
4. Palette CodeAssist → **« Jarvis Bridge : connecter le projet »** (une fois, sticky)
5. MegaJarvis ai et CodeAssist sur le **même appareil** (127.0.0.1:8080)

## Fichiers à copier dans ton arbre source MegaJarvis/Kai

```
composeApp/src/androidMain/kotlin/com/inspiredandroid/kai/codeassist/CodeAssistBridgeHttp.kt
composeApp/src/androidMain/kotlin/com/inspiredandroid/kai/tools/CodeAssistTools.kt
```

Puis dans `Platform.android.kt` :

1. `import com.inspiredandroid.kai.tools.CodeAssistTools`
2. Dans `getPlatformToolDefinitions()` ajouter `CodeAssistTools.toolInfo`
3. Dans `getAvailableTools()` → `platformExtras` :

```kotlin
if (appSettings.isToolEnabled(CodeAssistTools.ID)) {
    addAll(CodeAssistTools.allTools())
}
```

Un fichier `Platform.android.kt.PATCHED` est fourni comme référence (basé sur Kai upstream).

## Outils exposés à l’agent

| Outil | Action |
|--------|--------|
| `codeassist_health` | GET /health |
| `codeassist_list_files` | GET /files?path= |
| `codeassist_read_file` | GET /file?path= |
| `codeassist_write_file` | POST /file |
| `codeassist_delete_file` | DELETE /file |
| `codeassist_build` | POST /build |

Aucune simulation : les erreurs HTTP/plugin sont renvoyées telles quelles.

## Garde-fou

Le plugin ne donne accès qu’au **projet actuellement connecté** dans CodeAssist (pas un autre projet arbitraire).

## Activation UI

Paramètres → Tools → activer **CodeAssist Bridge** (si le toggle apparaît via `ToolInfo`).

## Différence avec le partage de blocs de code

| | Share ACTION_SEND | Pont HTTP |
|--|-------------------|-----------|
| Un bloc de code | Oui | Non nécessaire |
| Lister / lire / écrire tout le projet | Non | Oui |
| Build | Non | Oui (si plugin OK) |
| Contrôle éditeur | Non | Non |

Les deux peuvent coexister.

## Build

```bash
./gradlew :androidApp:assembleFossDebug
```

## Licence

- Client pont : fourni pour MegaJarvis (usage avec Kai Apache-2.0)
- CodeAssist reste GPL ; aucune copie de son code
